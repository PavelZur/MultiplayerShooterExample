using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField] private EnemyController _controller;
    public void Init(Player player)
    {
        player.OnChange += _controller.OnChangeHandler;
    }

    public void Kill()
    {
        Destroy(gameObject);
    }
}

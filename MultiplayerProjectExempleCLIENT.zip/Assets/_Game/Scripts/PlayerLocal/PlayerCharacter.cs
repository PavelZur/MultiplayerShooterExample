using UnityEngine;

public class PlayerCharacter : MonoBehaviour
{
    [SerializeField] private PlayerMovementModel _playerMovementModel;
    [SerializeField] private Rigidbody _rb;
    [SerializeField] private float _speedMove;

    private float _inputH;
    private float _inputV;
    private Vector3 _direction;

    public void SetInput(float h, float v)
    {
        _inputH = h;
        _inputV = v;
    }

    private void Move()
    {
        _direction = new Vector3(_inputH, 0f, _inputV).normalized;
        _rb.linearVelocity = _speedMove * _direction;
    }

    void FixedUpdate()
    {
        _playerMovementModel.PlayerPosition.Value = transform.position;
        _playerMovementModel.PlayerVelosity.Value = _direction * _speedMove;
        Move();
    }
}

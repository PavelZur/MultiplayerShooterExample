using UnityEngine;

public class InputController : MonoBehaviour
{
    [SerializeField] private PlayerCharacter _playerCharacter;

    void Update()
    {
        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical");

        _playerCharacter.SetInput(h, v);
    }
}

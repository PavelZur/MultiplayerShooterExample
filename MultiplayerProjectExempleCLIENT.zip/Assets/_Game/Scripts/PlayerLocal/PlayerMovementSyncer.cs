using System.Collections.Generic;
using UnityEngine;
using UniRx;

public class PlayerMovementSyncer : MonoBehaviour
{
    [SerializeField] private PlayerMovementModel _movementModel;
   

    private const string KEY_MOVE = "move";
    private readonly Dictionary<string, object> _movementInfoDictionaty = new()
    {
        { "x", 0f },
        { "y", 0f },
        { "vx", 0f },
        { "vy", 0f }
    };

    private void Start()
    {
        SendPosition(transform.position);
        //_movementModel.PlayerPosition.Skip(1).Subscribe(position => SendPosition(position)).AddTo(this);
    }

    private Vector3 PredictPositionOnPing(Vector3 cerrentPos)
    {
        float delaySec = (MultiplayerManager.Instance.RTT / 2) / 1000;       
        return cerrentPos + (_movementModel.PlayerVelosity.Value * delaySec);
    }

    private void FixedUpdate()
    {
        SendPosition(_movementModel.PlayerPosition.Value);
    }

    private void SendPosition(Vector3 pos)
    {
        Vector3 predictPosition = PredictPositionOnPing(pos);

        _movementInfoDictionaty["x"] = predictPosition.x;
        _movementInfoDictionaty["y"] = predictPosition.z;
        _movementInfoDictionaty["vx"] = _movementModel.PlayerVelosity.Value.x;
        _movementInfoDictionaty["vy"] = _movementModel.PlayerVelosity.Value.z;

        MultiplayerManager.Instance.SendMessage(KEY_MOVE, _movementInfoDictionaty);
    }
}
